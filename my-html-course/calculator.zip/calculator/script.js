let display = document.getElementById('display');
let currentNumber = '';

function appendNumber(number) {
  currentNumber += number;
  display.value = currentNumber;
}

function appendOperator(operator) {
  currentNumber += operator;
  display.value = currentNumber;
}

function calculate() {
  try {
    let result = eval(currentNumber);
    display.value = result;
    currentNumber = result.toString();
  } catch (error) {
    display.value = 'Error';
    currentNumber = '';
  }
}

function clearDisplay() {
  display.value = '';
  currentNumber = '';
}